import React, { useState } from 'react';
import API from '../api/axios';
import { Gauge, Search, Save, Trash2, Zap } from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';

// المتطلب الثالث: لوحة لإثبات الأداء والتخزين المؤقت من الواجهة
// تعرض رؤوس الخادم: X-Cache (Redis) و ETag و X-Query-Count و X-Response-Time و X-DB-Read-From
const readMetrics = (res, ms) => ({
  status: res.status,
  cache: res.headers['x-cache'] || '-',
  etag: res.headers['etag'] || '-',
  queries: res.headers['x-query-count'] || '-',
  serverTime: res.headers['x-response-time'] || '-',
  readFrom: res.headers['x-db-read-from'] || '-',
  clientTime: `${ms.toFixed(0)}ms`,
});

const timed = async (fn) => {
  const t = performance.now();
  const res = await fn();
  return { res, ms: performance.now() - t };
};

export default function AdminPerformance() {
  const [productId, setProductId] = useState('1');
  const [product, setProduct] = useState(null);
  const [form, setForm] = useState({ name: '', price: '', category: '', description: '' });
  const [log, setLog] = useState([]);

  const push = (label, m) => setLog((l) => [{ label, ...m, at: new Date().toLocaleTimeString() }, ...l].slice(0, 15));

  const load = async () => {
    try {
      const { res, ms } = await timed(() => API.get(`/api/v1/products/${productId}`));
      const p = res.data.data;
      setProduct(p);
      setForm({ name: p.name, price: p.price, category: p.category, description: p.description || '' });
      push(`GET /products/${productId}`, readMetrics(res, ms));
    } catch (e) {
      toast.error(e.response?.data?.error?.message || 'فشل جلب المنتج');
    }
  };

  const save = async () => {
    try {
      const { res, ms } = await timed(() => API.put(`/api/v1/products/${productId}`, form));
      push(`PUT /products/${productId}`, readMetrics(res, ms));
      toast.success('تم التعديل وحذف الكاش');
      await load(); // إثبات: التعديل يظهر فوراً (MISS ثم بيانات جديدة)
    } catch (e) {
      toast.error(e.response?.data?.error?.message || 'فشل التعديل');
    }
  };

  const remove = async () => {
    if (!confirm('حذف المنتج؟')) return;
    try {
      const { res, ms } = await timed(() => API.delete(`/api/v1/products/${productId}`));
      push(`DELETE /products/${productId}`, readMetrics(res, ms));
      setProduct(null);
      toast.success('تم الحذف');
    } catch (e) {
      toast.error(e.response?.data?.error?.message || 'فشل الحذف');
    }
  };

  const compareNPlusOne = async () => {
    try {
      const a = await timed(() => API.get('/api/v1/orders?naive=1'));
      push('GET /orders?naive=1 (N+1)', readMetrics(a.res, a.ms));
      const b = await timed(() => API.get('/api/v1/orders'));
      push('GET /orders (Eager Loading)', readMetrics(b.res, b.ms));
    } catch (e) {
      toast.error('فشل جلب الطلبات');
    }
  };

  const input = 'w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20';

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 font-sans" dir="rtl">
      <Toaster />
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
          <h1 className="text-2xl font-black text-slate-900 flex items-center gap-2">
            <Gauge className="w-6 h-6 text-indigo-600" /> الأداء والتخزين المؤقت
          </h1>
          <p className="text-slate-500 text-xs mt-1">
            اجلب منتجاً مرتين لترى HIT من Redis، عدّله لترى أن الكاش حُذف والتعديل ظهر فوراً، وقارن عدد الاستعلامات قبل وبعد حل N+1.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex gap-2">
              <input className={input} value={productId} onChange={(e) => setProductId(e.target.value)} placeholder="رقم المنتج" />
              <button onClick={load} className="flex items-center gap-1 bg-indigo-600 text-white px-4 rounded-xl text-sm font-bold">
                <Search className="w-4 h-4" /> جلب
              </button>
            </div>

            {product && (
              <>
                <div className="text-xs text-slate-500">
                  المخزون الحي (غير مخزن في الكاش): <b>{product.available_stock ?? '—'}</b> ({product.inventory_service_status})
                </div>
                <input className={input} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="الاسم" />
                <div className="grid grid-cols-2 gap-2">
                  <input className={input} type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="السعر" />
                  <input className={input} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="التصنيف" />
                </div>
                <textarea className={input} rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                <div className="flex gap-2">
                  <button onClick={save} className="flex-1 flex items-center justify-center gap-1 bg-emerald-600 text-white py-3 rounded-xl text-sm font-bold">
                    <Save className="w-4 h-4" /> حفظ التعديل
                  </button>
                  <button onClick={remove} className="flex items-center gap-1 bg-red-50 text-red-600 px-4 rounded-xl text-sm font-bold border border-red-100">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}

            <button onClick={compareNPlusOne} className="w-full flex items-center justify-center gap-1 bg-amber-50 text-amber-700 border border-amber-100 py-3 rounded-xl text-sm font-bold">
              <Zap className="w-4 h-4" /> مقارنة N+1 في قائمة الطلبات
            </button>
          </div>

          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm overflow-x-auto">
            <h2 className="font-bold text-slate-800 mb-3 text-sm">سجل القياسات</h2>
            <table className="w-full text-[11px] text-right">
              <thead className="text-slate-400">
                <tr><th>الطلب</th><th>Cache</th><th>SQL</th><th>الخادم</th><th>المتصفح</th><th>القراءة من</th></tr>
              </thead>
              <tbody>
                {log.map((r, i) => (
                  <tr key={i} className="border-t border-slate-100">
                    <td className="py-2 font-mono">{r.label}<div className="text-slate-400">{r.at} · {r.status}</div></td>
                    <td className={r.cache === 'HIT' ? 'text-emerald-600 font-bold' : 'text-amber-600 font-bold'}>{r.cache}</td>
                    <td>{r.queries}</td>
                    <td>{r.serverTime}</td>
                    <td>{r.clientTime}</td>
                    <td>{r.readFrom}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {log.length === 0 && <p className="text-xs text-slate-400 mt-4">لا توجد قياسات بعد.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
