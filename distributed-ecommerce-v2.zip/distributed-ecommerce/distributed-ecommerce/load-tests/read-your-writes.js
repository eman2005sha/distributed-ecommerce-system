// إثبات: تعديل منتج يظهر فوراً للمستخدم (رغم Redis و Read Replica و ETag)
// k6 run -e BASE_URL=http://localhost:8000/api/v1 -e PRODUCT_ID=1 load-tests/read-your-writes.js
import http from 'k6/http';
import { check } from 'k6';

const BASE = __ENV.BASE_URL || 'http://localhost:8000/api/v1';
const ID = __ENV.PRODUCT_ID || 1;
export const options = { vus: 1, iterations: 10 };

export function setup() {
  const r = http.post(`${BASE}/auth/login`, JSON.stringify({ email: 'admin@ecommerce.com', password: 'password123' }),
    { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } });
  return { token: r.json('data.access_token') };
}

export default function ({ token }) {
  const auth = { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const before = http.get(`${BASE}/products/${ID}`, { headers: auth });   // يملأ الكاش
  const etag = before.headers['Etag'];
  const newPrice = (Math.random() * 1000).toFixed(2);

  http.put(`${BASE}/products/${ID}`, JSON.stringify({ price: newPrice }), { headers: auth });

  const after = http.get(`${BASE}/products/${ID}`, { headers: { ...auth, 'If-None-Match': etag } });
  check(after, {
    'not 304 after edit (ETag changed)': (r) => r.status === 200,
    'new price visible immediately': (r) => Number(r.json('data.price')) === Number(newPrice),
    'cache was invalidated (MISS)': (r) => r.headers['X-Cache'] === 'MISS',
    'read served from primary': (r) => r.headers['X-Db-Read-From'] === 'primary',
  });
}
