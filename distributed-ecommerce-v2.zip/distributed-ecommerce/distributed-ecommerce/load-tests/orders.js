// اختبار ضغط قائمة الطلبات (يكشف N+1 والاستعلامات البطيئة على 300 ألف طلب)
// k6 run -e BASE_URL=http://localhost:8000/api/v1 -e NAIVE=1 load-tests/orders.js   <- قبل (N+1)
// k6 run -e BASE_URL=http://localhost:8000/api/v1 load-tests/orders.js              <- بعد
import http from 'k6/http';
import { check } from 'k6';
import { Trend } from 'k6/metrics';

const BASE = __ENV.BASE_URL || 'http://localhost:8000/api/v1';
const NAIVE = __ENV.NAIVE === '1';
const queries = new Trend('sql_queries_per_request');

export const options = {
  vus: 50,
  duration: '1m',
  summaryTrendStats: ['avg', 'p(50)', 'p(95)', 'p(99)', 'max'],
  thresholds: { http_req_failed: ['rate<0.01'] },
};

export function setup() {
  const r = http.post(`${BASE}/auth/login`, JSON.stringify({
    email: __ENV.EMAIL || 'admin@ecommerce.com',
    password: __ENV.PASSWORD || 'password123',
  }), { headers: { 'Content-Type': 'application/json', Accept: 'application/json' } });
  return { token: r.json('data.access_token') };
}

export default function ({ token }) {
  const page = Math.floor(Math.random() * 1000) + 1;
  const r = http.get(`${BASE}/orders?page=${page}${NAIVE ? '&naive=1' : ''}`, {
    headers: { Accept: 'application/json', Authorization: `Bearer ${token}` },
  });
  check(r, { '200': (x) => x.status === 200 });
  queries.add(Number(r.headers['X-Query-Count'] || 0));
}
