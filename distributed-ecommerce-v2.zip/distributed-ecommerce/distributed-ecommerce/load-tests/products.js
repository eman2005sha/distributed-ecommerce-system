// اختبار ضغط قراءة المنتجات (قائمة + تفاصيل) - يُشغَّل قبل التحسين وبعده
// k6 run -e BASE_URL=http://localhost:8000/api/v1 load-tests/products.js
// لمحاكاة "قبل": CACHE_STORE=array و ETAG=0 أو شغّله على نسخة الكود القديمة
import http from 'k6/http';
import { check } from 'k6';
import { Trend, Rate } from 'k6/metrics';

const BASE = __ENV.BASE_URL || 'http://localhost:8000/api/v1';
const USE_ETAG = (__ENV.ETAG || '1') === '1';
const listTime = new Trend('products_list_ms', true);
const showTime = new Trend('product_show_ms', true);
const notModified = new Rate('http_304_rate');
const cacheHit = new Rate('redis_cache_hit_rate');

export const options = {
  scenarios: {
    browse: {
      executor: 'ramping-vus',
      stages: [
        { duration: '30s', target: 50 },
        { duration: '1m', target: 200 },
        { duration: '30s', target: 0 },
      ],
    },
  },
  summaryTrendStats: ['avg', 'min', 'med', 'p(50)', 'p(95)', 'p(99)', 'max'],
  thresholds: {
    http_req_failed: ['rate<0.01'],
    'products_list_ms': ['p(95)<300'],
    'product_show_ms': ['p(95)<300'],
  },
};

const categories = ['', 'electronics', 'books', 'clothes', 'home'];
const etags = {};

export default function () {
  const page = Math.floor(Math.random() * 20) + 1;
  const cat = categories[Math.floor(Math.random() * categories.length)];
  const url = `${BASE}/products?page=${page}${cat ? `&category=${cat}` : ''}`;
  const headers = { Accept: 'application/json' };
  if (USE_ETAG && etags[url]) headers['If-None-Match'] = etags[url];

  const r = http.get(url, { headers });
  listTime.add(r.timings.duration);
  check(r, { 'list 200/304': (x) => x.status === 200 || x.status === 304 });
  notModified.add(r.status === 304);
  if (r.status === 200) {
    etags[url] = r.headers['Etag'];
    cacheHit.add(r.headers['X-Cache'] === 'HIT');
  }

  const id = Math.floor(Math.random() * 500) + 1;
  const s = http.get(`${BASE}/products/${id}`, { headers: { Accept: 'application/json' } });
  showTime.add(s.timings.duration);
  check(s, { 'show 200/404': (x) => x.status === 200 || x.status === 404 });
}
