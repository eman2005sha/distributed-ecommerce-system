# المتطلب الثالث: الأداء والتخزين المؤقت (Performance & Caching)

## 1. التشغيل
```bash
docker compose up -d --build
docker compose exec laravel-app composer require predis/predis
docker compose exec laravel-app php artisan migrate --seed
# بيانات وهمية كبيرة (300 ألف طلب افتراضياً، قابلة للتعديل)
docker compose exec -e SEED_ORDERS=300000 laravel-app php artisan db:seed --class=PerformanceSeeder
# التأكد من عمل النسخة القرائية
docker compose exec mysql-replica mysql -uroot -proot -e "SHOW REPLICA STATUS\G" | grep Running
```

## 2. قاعدة البيانات: EXPLAIN + الفهارس + N+1
| ما فعلناه | الملف |
|---|---|
| مولّد بيانات بالدفعات (bulk insert) | `database/seeders/PerformanceSeeder.php` |
| أمر يطبع EXPLAIN وزمن أهم الاستعلامات | `php artisan perf:explain` |
| فهارس مركبة حسب نتيجة EXPLAIN | `migrations/2026_11_07_000000_add_performance_indexes.php` |
| حل N+1 في قائمة الطلبات (Eager Loading + تحديد الأعمدة) | `OrderController@index` |
| رأس `X-Query-Count` لإظهار عدد الاستعلامات | `PerformanceMetricsMiddleware` |

مقارنة EXPLAIN قبل/بعد:
```bash
php artisan migrate:rollback --step=1 && php artisan perf:explain   # قبل
php artisan migrate && php artisan perf:explain                     # بعد
```
المتوقع: قبل -> `type=ALL` أو `Using filesort` مع `rows` بمئات الآلاف. بعد -> `type=ref/range` على الفهرس الجديد و`rows` صغيرة.

N+1: `GET /api/v1/orders?naive=1` مقابل `GET /api/v1/orders` — قارن الرأس `X-Query-Count` (≈ 30+ مقابل 4-5).

## 3. Read Replica
- `config/database.php`: `read` -> mysql-replica و `write` -> mysql-primary و `sticky => true`.
- `sticky`: داخل نفس الطلب، أي قراءة بعد كتابة تذهب للـ Primary.
- `ReadYourWritesMiddleware`: بعد كتابة المستخدم تُوجَّه قراءاته للـ Primary لمدة `READ_YOUR_WRITES_SECONDS` (أكبر من تأخر النسخ). الرأس `X-DB-Read-From` يبين المصدر.

## 4. Redis
| نخزّنه ✔ | لا نخزّنه ✘ |
|---|---|
| قائمة المنتجات (لكل صفحة/تصنيف) | المخزون المتوفر (يتغير مع كل طلب، خطؤه = بيع زائد) |
| تفاصيل المنتج الأساسية | طلبات المستخدم وبياناته (خاصة، خطر تسريبها لمستخدم آخر) |
| | التوكن وكلمات المرور ونتائج الدفع |

- انتهاء الصلاحية: TTL = `PRODUCT_CACHE_TTL` (600 ثانية).
- الحذف عند التعديل: `Product::booted()` يمسح `Cache::tags(['products'])` عند أي save/delete.
- الرأس `X-Cache: HIT|MISS`.

## 5. ETag (HTTP Caching)
`ETagMiddleware` على `GET /products` و `GET /products/{id}`: بصمة md5 للمحتوى، و`If-None-Match` المطابق -> **304** بدون جسم.
`Cache-Control: no-cache` يجعل المتصفح يتحقق دائماً، فيظهر تعديل المنتج فوراً.

## 6. اختبار الضغط (k6)
```bash
k6 run -e BASE_URL=http://localhost:8000/api/v1 load-tests/products.js
k6 run -e NAIVE=1 load-tests/orders.js     # قبل (N+1)
k6 run load-tests/orders.js                # بعد
k6 run load-tests/read-your-writes.js      # إثبات ظهور التعديل فوراً
```
"قبل" للمنتجات: شغّل مع `CACHE_STORE=array` في `.env` و `-e ETAG=0`، أو على نسخة الكود القديمة.

### جدول النتائج (املأه بأرقامك من مخرجات k6)
| السيناريو | p50 | p95 | p99 | طلبات/ث | أخطاء |
|---|---|---|---|---|---|
| المنتجات - قبل | | | | | |
| المنتجات - بعد | | | | | |
| الطلبات - قبل (N+1، بدون فهارس) | | | | | |
| الطلبات - بعد | | | | | |

### السلوك الذي نلاحظه عادةً (لكتابة التحليل)
- قبل: p99 يرتفع بشدة مع زيادة المستخدمين لأن كل طلب يقرأ من القاعدة، و`filesort` على 300 ألف صف، وعشرات الاستعلامات لكل صفحة طلبات (N+1)؛ تتراكم الطلبات في طابور الخادم.
- بعد: معظم القراءات HIT من Redis، ونسبة من الطلبات 304 بدون جسم (حجم نقل أقل)، والقراءات الباقية تذهب للنسخة القرائية فيخف الضغط عن الـ Primary؛ الفرق بين p50 و p99 يصغر.
- أول طلب بعد تعديل منتج يكون MISS (أبطأ قليلاً) ثم يعود HIT.
- `read-your-writes.js` يثبت أن السعر الجديد يظهر فوراً (200 وليس 304، و MISS، ومن primary).
