<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * المتطلب الثالث: فهارس مبنية على نتائج EXPLAIN.
 *
 * قبل: EXPLAIN SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC
 *      -> type=ref على مفتاح user_id ثم "Using filesort" على مئات آلاف الصفوف.
 * بعد: فهرس مركب (user_id, created_at) -> type=ref بدون filesort.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->index(['user_id', 'created_at'], 'orders_user_created_idx'); // طلبات الزبون مرتبة
            $table->index(['status', 'created_at'], 'orders_status_created_idx'); // تصفية الأدمن حسب الحالة
            $table->index('created_at', 'orders_created_idx');                    // قائمة الأدمن مرتبة
        });

        Schema::table('order_items', function (Blueprint $table) {
            // order_id و product_id لهما فهرس من الـ foreign key، نضيف فهرساً مغطياً لجلب العناصر
            $table->index(['order_id', 'product_id', 'quantity', 'unit_price'], 'order_items_covering_idx');
        });

        Schema::table('products', function (Blueprint $table) {
            $table->index(['category', 'id'], 'products_category_id_idx'); // التصفية + الترقيم
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropIndex('orders_user_created_idx');
            $table->dropIndex('orders_status_created_idx');
            $table->dropIndex('orders_created_idx');
        });
        Schema::table('order_items', fn (Blueprint $t) => $t->dropIndex('order_items_covering_idx'));
        Schema::table('products', fn (Blueprint $t) => $t->dropIndex('products_category_id_idx'));
    }
};
