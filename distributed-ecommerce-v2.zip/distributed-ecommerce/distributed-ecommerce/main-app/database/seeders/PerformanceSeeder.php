<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * المتطلب الثالث: بيانات وهمية بحجم كبير.
 * التشغيل: php artisan db:seed --class=PerformanceSeeder
 * الأحجام قابلة للتعديل عبر متغيرات البيئة: SEED_USERS, SEED_PRODUCTS, SEED_ORDERS
 * الإدخال يتم على دفعات (bulk insert) لأن Eloquent سطراً بسطر بطيء جداً مع 300 ألف طلب.
 */
class PerformanceSeeder extends Seeder
{
    public function run(): void
    {
        $users = (int) env('SEED_USERS', 5000);
        $products = (int) env('SEED_PRODUCTS', 2000);
        $orders = (int) env('SEED_ORDERS', 300000);
        $chunk = 2000;
        $now = now()->toDateTimeString();
        $password = Hash::make('password');
        $categories = ['electronics', 'books', 'clothes', 'home', 'sports', 'toys', 'beauty', 'food'];

        DB::disableQueryLog();

        $this->command->info("Users: $users");
        for ($i = 0; $i < $users; $i += $chunk) {
            $rows = [];
            for ($j = $i; $j < min($i + $chunk, $users); $j++) {
                $rows[] = ['name' => "Load User $j", 'email' => "load$j@test.com", 'password' => $password,
                    'role' => 'customer', 'created_at' => $now, 'updated_at' => $now];
            }
            DB::table('users')->insertOrIgnore($rows);
        }

        $this->command->info("Products: $products");
        $prices = [];
        for ($i = 0; $i < $products; $i += $chunk) {
            $rows = [];
            for ($j = $i; $j < min($i + $chunk, $products); $j++) {
                $rows[] = ['name' => "Product $j", 'description' => "Generated product number $j",
                    'price' => mt_rand(100, 100000) / 100, 'category' => $categories[$j % count($categories)],
                    'created_at' => $now, 'updated_at' => $now];
            }
            DB::table('products')->insert($rows);
        }
        $productIds = DB::table('products')->pluck('price', 'id')->all();
        $pIds = array_keys($productIds);
        $uIds = DB::table('users')->where('role', 'customer')->pluck('id')->all();
        $statuses = ['pending', 'processing', 'shipped', 'completed', 'cancelled'];

        $this->command->info("Orders: $orders (+ ~2 items each)");
        $bar = $this->command->getOutput()->createProgressBar((int) ceil($orders / $chunk));
        for ($i = 0; $i < $orders; $i += $chunk) {
            DB::transaction(function () use ($i, $chunk, $orders, $uIds, $pIds, $productIds, $statuses) {
                $count = min($chunk, $orders - $i);
                $rows = [];
                for ($k = 0; $k < $count; $k++) {
                    $d = now()->subMinutes(mt_rand(0, 525600))->toDateTimeString();
                    $rows[] = ['user_id' => $uIds[array_rand($uIds)], 'total_price' => 0,
                        'status' => $statuses[array_rand($statuses)], 'created_at' => $d, 'updated_at' => $d];
                }
                DB::table('orders')->insert($rows);
                $firstId = (int) DB::getPdo()->lastInsertId(); // MySQL: أول id في الدفعة
                $items = [];
                for ($k = 0; $k < $count; $k++) {
                    for ($n = 0, $m = mt_rand(1, 3); $n < $m; $n++) {
                        $pid = $pIds[array_rand($pIds)];
                        $items[] = ['order_id' => $firstId + $k, 'product_id' => $pid, 'quantity' => mt_rand(1, 4),
                            'unit_price' => $productIds[$pid], 'created_at' => $rows[$k]['created_at'], 'updated_at' => $rows[$k]['created_at']];
                    }
                }
                foreach (array_chunk($items, 2000) as $c) DB::table('order_items')->insert($c);
            });
            $bar->advance();
        }
        $bar->finish();
        $this->command->newLine();

        // حساب الإجمالي بجملة SQL واحدة بدل حلقة (تجنب N+1 أثناء التوليد أيضاً)
        DB::statement('UPDATE orders o JOIN (SELECT order_id, SUM(quantity*unit_price) t FROM order_items GROUP BY order_id) x
                       ON x.order_id = o.id SET o.total_price = x.t');
        $this->command->info('Done.');
    }
}
