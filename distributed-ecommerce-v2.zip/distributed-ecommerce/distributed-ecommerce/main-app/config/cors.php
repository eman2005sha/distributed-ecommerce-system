<?php

return [
    'paths' => ['api/*'],
    'allowed_methods' => ['*'],
    'allowed_origins' => ['*'],
    'allowed_origins_patterns' => [],
    'allowed_headers' => ['*'], // يشمل If-None-Match
    // المتطلب الثالث: كشف رؤوس القياس للواجهة الأمامية
    'exposed_headers' => ['ETag', 'X-Cache', 'X-Query-Count', 'X-Response-Time', 'X-DB-Read-From'],
    'max_age' => 0,
    'supports_credentials' => false,
];
