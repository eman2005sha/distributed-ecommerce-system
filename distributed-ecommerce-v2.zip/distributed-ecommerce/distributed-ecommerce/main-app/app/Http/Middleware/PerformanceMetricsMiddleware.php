<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

/**
 * يضيف رؤوساً تثبت التحسين بالأرقام في كل استجابة:
 *  X-Query-Count  : عدد استعلامات SQL (يكشف مشكلة N+1 فوراً)
 *  X-Response-Time: زمن المعالجة في الخادم
 */
class PerformanceMetricsMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $start = microtime(true);
        $count = 0;
        DB::listen(function () use (&$count) { $count++; });

        $response = $next($request);

        $response->headers->set('X-Query-Count', (string) $count);
        $response->headers->set('X-Response-Time', sprintf('%.2fms', (microtime(true) - $start) * 1000));
        return $response;
    }
}
