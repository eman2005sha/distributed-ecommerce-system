<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * المتطلب الثالث: التخزين المؤقت في HTTP عبر ETag.
 * - يحسب بصمة (hash) لمحتوى الاستجابة.
 * - إذا أرسل العميل If-None-Match بنفس البصمة -> 304 Not Modified بدون جسم.
 * - Cache-Control: no-cache يجبر المتصفح على التحقق في كل مرة، فيظهر أي تعديل على المنتج فوراً.
 */
class ETagMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        if (!$request->isMethodCacheable() || $response->getStatusCode() !== 200) {
            return $response;
        }

        $etag = '"' . md5((string) $response->getContent()) . '"';
        $response->headers->set('ETag', $etag);
        $response->headers->set('Cache-Control', 'no-cache, private');

        $clientTags = array_map('trim', explode(',', (string) $request->header('If-None-Match')));
        if (in_array($etag, $clientTags, true) || in_array('W/' . $etag, $clientTags, true)) {
            $response->setNotModified(); // 304 + يحذف الجسم
        }

        return $response;
    }
}
