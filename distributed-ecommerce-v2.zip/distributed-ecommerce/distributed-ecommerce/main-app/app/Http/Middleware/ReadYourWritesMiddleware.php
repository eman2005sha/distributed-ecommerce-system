<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

/**
 * المتطلب الثالث: Read Replica مع ضمان "اقرأ ما كتبته".
 * - داخل نفس الطلب: 'sticky' => true في config/database.php.
 * - بين الطلبات: بعد أي كتابة من المستخدم نضع علامة في Redis لعدة ثوانٍ (أكبر من تأخر النسخ)،
 *   وخلالها تُوجَّه قراءاته إلى الـ Primary بدلاً من النسخة التي قد تكون متأخرة.
 */
class ReadYourWritesMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = auth('api')->user();
        $key = $user ? "ryw:user:{$user->id}" : null;

        if ($key && Cache::has($key)) {
            DB::connection()->recordsHaveBeenModified(); // مع sticky: كل القراءات التالية من الـ Primary
            $forced = true;
        }

        $response = $next($request);

        if ($key && !$request->isMethodSafe() && $response->isSuccessful()) {
            Cache::put($key, 1, (int) env('READ_YOUR_WRITES_SECONDS', 5));
        }

        $response->headers->set('X-DB-Read-From', !empty($forced) || DB::connection()->hasModifiedRecords() ? 'primary' : 'replica');
        return $response;
    }
}
