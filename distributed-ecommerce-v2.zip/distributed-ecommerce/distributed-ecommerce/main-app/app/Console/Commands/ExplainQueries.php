<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

/**
 * php artisan perf:explain
 * يطبع خطة تنفيذ (EXPLAIN) أهم الاستعلامات البطيئة + زمن تنفيذها، لمقارنة ما قبل/بعد الفهارس.
 * للمقارنة: php artisan migrate:rollback --step=1 ثم perf:explain ثم migrate ثم perf:explain
 */
class ExplainQueries extends Command
{
    protected $signature = 'perf:explain';
    protected $description = 'EXPLAIN + timing for the hottest queries (Performance requirement)';

    public function handle(): int
    {
        $userId = DB::table('orders')->value('user_id') ?? 1;
        $queries = [
            'customer orders (sorted)' => ["SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 10", [$userId]],
            'admin orders by status' => ["SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC LIMIT 10", ['pending']],
            'admin orders count' => ["SELECT COUNT(*) FROM orders WHERE status = ?", ['pending']],
            'products by category' => ["SELECT * FROM products WHERE category = ? ORDER BY id LIMIT 10 OFFSET 100", ['books']],
            'best sellers' => ["SELECT product_id, SUM(quantity) q FROM order_items GROUP BY product_id ORDER BY q DESC LIMIT 10", []],
        ];

        foreach ($queries as $name => [$sql, $bind]) {
            $this->info("== $name");
            $this->line($sql);
            $plan = DB::select("EXPLAIN $sql", $bind);
            $this->table(array_keys((array) $plan[0]), array_map(fn ($r) => (array) $r, $plan));
            $t = microtime(true);
            DB::select($sql, $bind);
            $this->comment(sprintf('time: %.2f ms', (microtime(true) - $t) * 1000));
            $this->newLine();
        }
        return self::SUCCESS;
    }
}
