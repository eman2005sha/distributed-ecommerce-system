<?php

namespace App\Modules\Products\Controllers;

use App\Http\Controllers\Controller;
use App\Modules\Products\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * المتطلب الثالث - ما الذي نخزنه في Redis وما الذي لا نخزنه:
     *  ✔ قائمة المنتجات وتفاصيل المنتج الأساسية: أكثر البيانات قراءة، عامة لكل المستخدمين، وتتغير نادراً.
     *  ✘ الكمية المتوفرة (stock): تتغير مع كل طلب وخطأها يسبب بيعاً زائداً -> تُجلب حية من خدمة المستودع.
     *  ✘ طلبات المستخدم وبياناته والتوكن: خاصة بكل مستخدم وحساسة، وتخزينها يخاطر بتسريبها لمستخدم آخر.
     * TTL = PRODUCT_CACHE_TTL (افتراضياً 10 دقائق) + حذف فوري عند التعديل (انظر Product::booted).
     */
    private function ttl(): int
    {
        return (int) env('PRODUCT_CACHE_TTL', 600);
    }

    // 1. عرض كل المنتجات مع التصفية وتقسيم الصفحات (Pagination & Filtering) + كاش Redis
    public function index(Request $request)
    {
        $page = max(1, (int) $request->query('page', 1));
        $category = $request->query('category');
        $key = 'products:index:' . md5(json_encode([$category, $page]));
        $hit = Cache::tags(['products'])->has($key);

        $products = Cache::tags(['products'])->remember($key, $this->ttl(), function () use ($category) {
            $query = Product::query()
                ->select(['id', 'name', 'description', 'price', 'category', 'image_path', 'updated_at'])
                ->orderBy('id');

            // التصفية حسب التصنيف إذا وُجد في الرابط (مثل ?category=electronics)
            if ($category) {
                $query->where('category', $category); // يستخدم الفهرس products_category_id_idx
            }

            // التقسيم إلى صفحات (Pagination) - كل صفحة 10 منتجات افتراضياً
            return $query->paginate(10)->toArray();
        });

        return response()->json([
            'success' => true,
            'data' => $products
        ])->header('X-Cache', $hit ? 'HIT' : 'MISS');
    }

    // 2. إضافة منتج جديد (متاح فقط للـ Admin)
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'category' => 'required|string|max:100',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'VALIDATION_ERROR',
                    'message' => 'بيانات المنتج غير صالحة.',
                    'details' => $validator->errors()
                ]
            ], 422);
        }

        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $product = Product::create([
            'name' => $request->name,
            'description' => $request->description,
            'price' => $request->price,
            'category' => $request->category,
            'image_path' => $imagePath,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'تم إضافة المنتج بنجاح',
            'data' => $product
        ], 201);
    }

    // 3. عرض تفاصيل منتج واحد مع جلب الكمية المتوفرة من خدمة المستودع (gRPC)
    public function show($id)
    {
        $key = "products:show:{$id}";
        $hit = Cache::tags(['products'])->has($key);
        $cached = Cache::tags(['products'])->remember($key, $this->ttl(), fn () => Product::find($id)?->toArray());
        $product = $cached ? (new Product)->forceFill($cached) : null;

        if (!$product) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'NOT_FOUND',
                    'message' => 'المنتج غير موجود.'
                ]
            ], 404);
        }

        // سؤال خدمة المستودع عن الكمية المتوفرة عبر gRPC
        $availableStock = null;
        $inventoryStatus = 'online';

        try {
            $grpcResponse = Http::timeout(2)->get("http://inventory-service:50052/stock/{$product->id}");
            if ($grpcResponse->successful()) {
                $availableStock = $grpcResponse->json('available_stock');
            } else {
                $inventoryStatus = 'error';
            }
        } catch (\Exception $e) {
            // في حال كانت خدمة المستودع متوقفة لا يتعطل عرض المنتج بل يوضح حالة المستودع
            $inventoryStatus = 'offline (inventory service unavailable)';
        }

        // المخزون لا يُخزن في الكاش: يُضاف حياً فوق بيانات المنتج المخزنة
        $productData = $cached;
        $productData['available_stock'] = $availableStock;
        $productData['inventory_service_status'] = $inventoryStatus;

        return response()->json([
            'success' => true,
            'data' => $productData
        ])->header('X-Cache', $hit ? 'HIT' : 'MISS');
    }

    // 4. تعديل منتج (أدمن) - يحذف الكاش تلقائياً فيظهر التعديل فوراً
    public function update(Request $request, $id)
    {
        $product = Product::find($id);
        if (!$product) {
            return response()->json(['success' => false, 'error' => ['code' => 'NOT_FOUND', 'message' => 'المنتج غير موجود.']], 404);
        }

        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'sometimes|required|numeric|min:0',
            'category' => 'sometimes|required|string|max:100',
        ]);
        if ($validator->fails()) {
            return response()->json(['success' => false, 'error' => [
                'code' => 'VALIDATION_ERROR', 'message' => 'بيانات المنتج غير صالحة.', 'details' => $validator->errors()]], 422);
        }

        $product->update($validator->validated()); // saved event -> Cache::tags(products)->flush()

        return response()->json(['success' => true, 'message' => 'تم تعديل المنتج وتحديث الكاش', 'data' => $product]);
    }

    // 5. حذف منتج (أدمن)
    public function destroy($id)
    {
        $product = Product::find($id);
        if (!$product) {
            return response()->json(['success' => false, 'error' => ['code' => 'NOT_FOUND', 'message' => 'المنتج غير موجود.']], 404);
        }
        $product->delete();
        return response()->json(['success' => true, 'message' => 'تم حذف المنتج']);
    }
}