<?php

namespace App\Modules\Products\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Product extends Model
{
    protected $fillable = [
        'name',
        'description',
        'price',
        'category',
        'image_path',
    ];

    /**
     * المتطلب الثالث - سياسة الحذف من الكاش عند التعديل:
     * أي إنشاء/تعديل/حذف لمنتج يمسح كل مفاتيح كاش المنتجات (tag: products)
     * فيظهر التعديل للمستخدم فوراً ولا ننتظر انتهاء الـ TTL.
     */
    protected static function booted(): void
    {
        $flush = fn () => Cache::tags(['products'])->flush();
        static::saved($flush);
        static::deleted($flush);
    }
}
